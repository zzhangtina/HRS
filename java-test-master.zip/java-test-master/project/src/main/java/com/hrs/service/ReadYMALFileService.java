package com.hrs.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrs.model.Readings;

import java.io.File;
import java.io.IOException;

public class ReadYMALFileService implements ReadFileService {
    public Readings[] readFile(String name) throws IOException {
       return null;
        }
}
