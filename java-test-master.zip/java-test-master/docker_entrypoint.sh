#!/usr/bin/env bash
/usr/local/openjdk-8/bin/java -jar /code/test.jar "${READINGS_FILE}" "${RULES_FILE}"
